package com.example.ukhantukka

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
